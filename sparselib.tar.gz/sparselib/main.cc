#include<iostream>
#include "sparselib.hh"

using namespace ::std;
using namespace ::sparselib_load;
using ::sparselib::index_type ;
using ::sparselib_fun::maxval ;
using ::sparselib_fun::minval ;
using ::sparselib_fun::absval ;

int main() {
    // NOT  to mix up with vector<T> from lib <vector>!!!!!!
    Vector<double> x,b; // alternative Vector<double> x(4),b(4); 
    x.new_dim(4);       // vector of Dimension 4
    b.new_dim(4);      
    CCoorMatrix<double> A; // alternative CCoorMatrix<int> A(4,4,6);
    A.new_dim(4,4,6);  // 4x4 Matrix with 6 non-zero Elements (can be used for changes) 
    x=1; // sets all components to 1
    x[2]=2; // set 2nd element (1st x[0])

    int i;   // or use index_type i;
    int j; 

    for (i=0; i<4; i++)	A.insert(i,i)=1;  // insert values into Matrix
    A.insert(3,1)=1;    
    A.insert(3,0)=1;

    cout << A << "\n";  // output of matrix
    
    b=A*x; // multiplication of matrix and vector
    cout << b << "\n";  
    

    IdPreco<int> P;  // preconditioner, used for solver
    P.build(A); //  used for solver
    int iter, max_iter=100; // number of iterations for iterative solver
    double epsi=0.01;  // tolerance
    x=0;
    double res=bicgstab(A,b,x, P, epsi, max_iter, iter); // this solver seems to work
    cout << " solution for x " << x << "\n";

    b=0; 
    b[1]=1; // set 2nd element (1st b[0])
    x=0;
    iter=0;
    res=bicgstab(A,b,x, P, epsi, max_iter, iter);
    b=A*x;
    cout << " solution for x " << x <<  "\n" << " verification for b " << b << "\n";
   
}

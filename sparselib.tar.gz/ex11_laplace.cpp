#include<iostream>
#include "sparselib/sparselib.hh"

//resolver A x = b, em que A é uma matriz e x e b vetores

using namespace ::std;
using namespace ::sparselib_load;
using ::sparselib::index_type ;
using ::sparselib_fun::maxval ;
using ::sparselib_fun::minval ;
using ::sparselib_fun::absval ;

int main() {

    Vector<double> x,b; // definir vetores x e b
    CCoorMatrix<double> A; // definir matriz A

    x.new_dim(9);       //definir dimensão do vetor de incognitas
    b.new_dim(9);       //definir dimensao do vetor b
    A.new_dim(9,9,25);  //matrix de 9x9 com 25 elementos não nulos 
    b=0; //definir todas as componentes de b como zero
    b[0]=-1; //definir valor da primeira componente de b

    cout << b << "\n"; //imprimir vetor b

    int i; 

    //inserir valores na matriz A
    for (i=0; i<9; i++)	A.insert(i,i)=-2;
    A.insert(0,1)=+1;    
    A.insert(8,7)=+1;
    for (i=1; i<8; i++) 
    { A.insert(i,i-1)=+1; 
      A.insert(i,i+1)=+1;
    }

    cout << A << "\n";  //imprimir A

    x=0;

    IdPreco<int> P;  // preconditioner, used for solver
    P.build(A); //  used for solver
    int iter, max_iter=100; // number of iterations for iterative solver
    double epsi=0.01;  // tolerance
    x=0;
    double res=bicgstab(A,b,x, P, epsi, max_iter, iter); //solver
    cout << " solution for x " << x << "\n";
    
    cout << x << endl;

}
